import os

p=os.path.dirname(__file__)
print os.path.dirname(__file__)
print os.path.join(p)