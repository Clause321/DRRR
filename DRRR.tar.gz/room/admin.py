from django.contrib import admin
from room.models import ChatRoom

admin.site.register(ChatRoom)